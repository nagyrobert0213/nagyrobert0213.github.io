public class FavoriteNumber {
    public static void main(String[] args){
        int favoriteNumber = 13;
        System.out.println("Your favorite number is " + favoriteNumber +   "!");
    }
}
