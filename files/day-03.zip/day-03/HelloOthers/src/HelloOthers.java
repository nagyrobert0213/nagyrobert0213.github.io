public class HelloOthers {
    public static void main(String[] args){
        System.out.println("Hello, Csilla");
        System.out.println("Hello, Robi");
        System.out.println("Hello, Dani");
    }
}
