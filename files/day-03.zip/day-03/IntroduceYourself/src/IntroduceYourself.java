public class IntroduceYourself {
    public static void main(String[] args){
        System.out.println("Nagy Robert");
        System.out.println("21" );
        System.out.println("1.80");
    }
}
