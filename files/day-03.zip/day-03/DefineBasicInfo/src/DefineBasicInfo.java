public class DefineBasicInfo {
    public static void main (String[] args){
        String name = "Robert Nagy";
        int age = 21;
        double heightInMetre = 1.80;
        boolean married = false;
        System.out.println(name);
        System.out.println(age);
        System.out.println(heightInMetre);
        System.out.println(married);
    }
}
