public class HumptyDumpty {

    public static void main(String[] args){
        //prints out humpty dumpty riddle

        /*Humpty Dumpty sat on a wall,
        Humpty Dumpty had a great fall.
        All the king's horses and all the king's men
        Couldn't put Humpty together again
        */
        System.out.println("Humpty Dumpty sat on a wall,");
        System.out.println("Humpty Dumpty had a great fall.");
        System.out.println("All the king's horses and all the king's men");
        System.out.println("Couldn't put Humpty together again");
    }
}
