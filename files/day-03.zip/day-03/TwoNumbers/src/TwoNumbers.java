public class TwoNumbers {
    public static void main(String[] args){


        System.out.println(13 + 22);
        System.out.println(13 - 22);
        System.out.println(22 * 13);
        System.out.println(22. / 13.);
        int n1 = 22;
        System.out.println(n1 / 13);
        System.out.println(22 % 13);

    }
}
